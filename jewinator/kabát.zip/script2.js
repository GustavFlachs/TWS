
let cenaKabat = 2500;

if (cenaKabat < 1000) {
    console.log("příliš levné");
} else if (cenaKabat >= 1000 & cenaKabat < 3000) {
    console.log("přijatelná cena");
} else if (cenaKabat >= 3000) {
    console.log("příliš drahé");
}
